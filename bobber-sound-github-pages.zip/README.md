# Bobber Sound

Simulator suara mesin V-twin (Bobber Custom, Harley Cruiser, Harley Bass).
Mendukung mode GPS dan sensor gerak, bisa dipasang ke layar utama HP seperti aplikasi.

## Cara memasang di GitHub Pages
1. Buat akun di https://github.com (kalau belum punya).
2. Klik **New repository**. Nama bebas, misalnya `bobber-sound`. Pilih **Public**. Klik **Create repository**.
3. Di halaman repo, klik **uploading an existing file** (atau Add file, lalu Upload files).
4. Upload SEMUA isi folder ini: `index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png`. Klik **Commit changes**.
5. Buka **Settings**, lalu **Pages**. Pada "Build and deployment", pilih Source: **Deploy from a branch**, Branch: **main**, folder: **/ (root)**. Klik **Save**.
6. Tunggu 1 sampai 2 menit. Alamatnya: `https://NAMA-GITHUB-ANDA.github.io/bobber-sound/`

## Memasang ke layar utama HP
- **Android (Chrome / Samsung Internet):** buka alamatnya, menu titik tiga, lalu **Tambahkan ke layar utama** atau **Instal aplikasi**.
- **iPhone (Safari):** tombol Bagikan, lalu **Tambah ke Layar Utama**.

## Catatan
- Mode GPS dan sensor gerak butuh alamat `https` (GitHub Pages sudah https) dan izin lokasi.
- Setelah dipasang, aplikasi tetap bisa dibuka tanpa internet (kecuali GPS).
- Kalau Anda mengubah isi file nanti, naikkan angka versi di `sw.js` (`bobber-sound-v1` jadi `v2`) supaya HP mengambil versi terbaru.
